class PlayGame extends Phaser.Scene {
    constructor() {
        super("playGame");
    }

    preload() {
        this.load.spritesheet('ps', '/assets/images/sprite1.png', {
            frameWidth: 50,
            frameHeight: 50
        });
        this.load.image('obstacle', '/assets/images/knife.png');
    }
    create() {
        var esc = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ESC);
        var scoreText;
        this.cursorKeys = this.input.keyboard.createCursorKeys();

        //ANNIMATION SPRITE
        this.anims.create({
            key: 'move',
            frames: this.anims.generateFrameNumbers('ps'),
            frameRate: 15,
            repeat: -1
        });

        persoSprite = this.physics.add.sprite(200, 250, 'ms').setScale(1);
        persoSprite.play('move');
        persoSprite.setCollideWorldBounds(true);

        // Affichage du score
        let scoreStyle = {
            font: '20px Arial',
            fill: '#000'
        };
        this.score = 0;
        this.scoreText = this.add.text(20, 20, score, scoreStyle);

        // Generation obstacle
        this.time.addEvent({
            delay: 1000,
            callback: nouvelObjet,
            callbackScope: this,
            loop: true,
        });

    }
    update() {
        this.physics.add.collider(persoSprite, obstacle, function () {
            this.scene.stop();
            this.scene.launch("endGame");
        }, null, this);
        // Déplacement
        if (Phaser.Input.Keyboard.JustDown(this.cursorKeys.left) && persoSprite.x > 80) {
            persoSprite.x -= 60;
        }
        if (Phaser.Input.Keyboard.JustDown(this.cursorKeys.right) && persoSprite.x < 320) {
            persoSprite.x += 60;
        }
        // Pause
        if (Phaser.Input.Keyboard.JustDown(this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ESC))) {
            console.log("pause");
            this.scene.pause("playGame");
            this.scene.launch('pauseGame');
        }
    }
}

function nouvelObjet() {
    this.score += 1;
    console.log(this.score);
    this.scoreText.setText(this.score);

    var trou = Phaser.Math.Between(1, 5);
    var trou2 = Phaser.Math.Between(1, 5);

    obstacle = this.physics.add.group();

    for (var i = 1; i < 6; i++) {
        if (i != trou && i != trou2) {
            obstacle.create((20 + (60 * i)), 500, 'obstacle');
        }
        obstacle.setVelocityY(-200);
    }
}