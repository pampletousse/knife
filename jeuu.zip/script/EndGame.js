class EndGame extends Phaser.Scene {
    constructor() {
        super("endGame");
    }
    create() {
        this.add.text(200, 200, "Fin", {
            font: "25px Arial",
            fill: "#000"
        });
        this.add.text(20, 20, "SCORE : " + score, {
            font: "30px Arial",
            fill: "#000",
        });
        this.add.text(20, 100, "Appuyer sur entrée pour rejouer", {
            font: "18px Arial",
            fill: "#000",
        });
    }
    update() {
        if (Phaser.Input.Keyboard.JustDown(this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ENTER))) {
            console.log("resume");
            this.scene.stop();
            this.scene.start('playGame');
        }
    }
}