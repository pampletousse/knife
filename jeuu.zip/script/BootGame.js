class BootGame extends Phaser.Scene {
    constructor() {
        super("bootGame");
    }

    create() {
        this.add.text(20, 20, "JEU", {
            font: "30px Arial",
            fill: "#000"
        });
        this.add.text(20, 100, "Appuyer sur entrée pour jouer", {
            font: "18px Arial",
            fill: "#000"
        });
        this.add.text(20, 150, "Appuyer sur esc pour faire pause", {
            font: "18px Arial",
            fill: "#000"
        });
    }

    update() {
        if (Phaser.Input.Keyboard.JustDown(this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ENTER))) {
            console.log("resume");
            this.scene.stop("bootGame");
            this.scene.start("playGame");
        }
    }
}